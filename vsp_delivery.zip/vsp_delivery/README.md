# VSP碳排放模型优化与最终交付

## 目录
- `vsp_input/`：上传文件的只读副本；原始附件未被修改。
- `vsp_delivery/`：所有生成的模型、报告、对照、测试日志和清单。
- 工作区根目录 `vsp_delivery.zip`：最终交付包。

## 模型口径
- 主口径：按车辆物理行程去重，键为车牌、里程、封车时间、解封车时间、发车网点、到达网点；不含运单号。
- 辅口径：按运单映射保留运单号，用于运单级归因/分摊。不可将其直接解释为独立物理行程总量。
- 排放公式：单趟排放（kgCO₂）=里程（km）×代表排放因子（gCO₂/km）÷1000。
- 排放因子沿用方案4.4可追溯代表值，属于代理参数，不是逐车实测因子。
- 无真实油耗或实测CO₂数据，故不进行独立精度验证，不宣称精度提升。

## 运行环境
Python 3.10+；依赖见 `requirements.txt`。本次环境使用当前可用的 pandas、numpy、openpyxl 运行；若在新环境中运行，可执行 `python -m pip install -r vsp_delivery/requirements.txt`。

## 运行
从工作区根目录执行：
```bash
python vsp_delivery/original_reproduction.py
python vsp_delivery/improved_model.py
python vsp_delivery/run_all.py
```
脚本输入路径固定为根目录 `vsp_input/`，输出写入 `vsp_delivery/`。`run_all.py` 将运行模型脚本、检查必需文件、检查Excel可读性并记录结果。

## 重要数据审计提醒
原始运单时间戳覆盖全年，月份包含2023-01、2023-02、2023-03、2023-11、2023-12；原方案文档所称仅四个月数据期与原始附件覆盖范围不完全一致。当前不静默删除3月记录。
