# VSP碳排放模型优化与最终交付清单

## 实际目录
- 输入副本目录：`/mnt/data/vsp_input/`（原始文件未修改；该目录不纳入输出压缩包）
- 输出目录：`/mnt/data/vsp_delivery/`
- 最终压缩包：`/mnt/data/vsp_delivery.zip`

## 核心结果（模型估算，非实测）
- 主口径物理行程：12,167 趟；里程 2,174,173.86 km；代表因子模型排放 2,338.931589 tCO₂。
- 辅口径运单映射：33,214 条关联记录；里程 4,690,435.81 km；代表因子模型排放 4,649.103921 tCO₂。
- 未提供真实油耗或实测CO₂，未进行独立精度验证，不宣称精度提升。
- 原始数据覆盖月份包含 2023-01、2023-02、2023-03、2023-11、2023-12；报告中四个月口径与原始数据覆盖存在差异，已在报告中披露。

## 必交项逐项状态
- `data_audit.xlsx` — 已生成；Excel已打开检查；含字段、缺失、重复、异常、关联与整理版差异核对。
- `data_quality.md` — 已生成；说明关键数据质量问题和影响。
- `original_reproduction.py` — 已生成并运行通过；按原始附件重建运单映射口径。
- `original_reproduction.xlsx` — 已生成；Excel已打开检查；旧口径复现值与文档声明值分列说明。
- `parameter_source.xlsx` — 已生成；Excel已打开检查；参数/规则分类、来源、公式与限制。
- `improved_model.py` — 已生成并运行通过；按原始附件重建物理行程主模型。
- `improved_model.xlsx` — 已生成；Excel已打开检查；含逐行行程、车型映射、汇总、数据质量、参数来源和模型说明。
- `model_change_log.md` — 已生成；记录依据、公式、适用条件和局限。
- `model_improvement_report.md` — 已生成；汇总改进、结果差异、敏感性、证据边界。
- `comparison.xlsx` — 已生成；Excel已打开检查；含主辅口径结果、差异归因和适用场景。
- `sensitivity.xlsx` — 已生成；Excel已打开检查；含速度、因子乘数与车型映射敏感性。
- `comparison_report.md` — 已生成；明确不把结果变化解释为精度提升。
- `run_all.py` — 已生成并运行通过；连续运行模型脚本两次并检查必需文件与Excel。
- `requirements.txt` — 已生成；列出运行依赖。
- `README.md` — 已生成；说明目录、模型口径和运行方法。
- `test_run.md` — 已生成；记录端到端、重复性和文件可读性测试。

## 全部输出文件（相对 `vsp_delivery/`）
- `README.md`
- `comparison.xlsx`
- `comparison_report.md`
- `data_audit.xlsx`
- `data_quality.md`
- `improved_model.py`
- `improved_model.xlsx`
- `logs/round_1_end_to_end.log`
- `logs/round_2_repeatability.log`
- `logs/round_3_manifest_excel.log`
- `logs/run_all.log`
- `model_change_log.md`
- `model_improvement_report.md`
- `original_reproduction.py`
- `original_reproduction.xlsx`
- `parameter_source.xlsx`
- `requirements.txt`
- `run_all.py`
- `sensitivity.xlsx`
- `test_run.md`

## 未完成项与限制
- **未完成独立精度验证**：原因是输入文件没有真实油耗或实测CO₂数据；按用户确定的停止/证据规则，不伪造验证结果。
- **未提交GitHub版本**：用户定义为可选，不阻塞交付。
- 物理行程键缺少业务系统唯一行程ID，仍可能存在同键误合并或拆分风险；车型代表因子是代理值。
- 原始数据范围与方案文档数据期不一致，最终业务口径仍需项目方确认；本次严格保留原始附件日期，不静默剔除2023年3月记录。

## 打包状态
- `vsp_delivery.zip` 在工作区根目录生成，包含本清单及 `vsp_delivery/` 内所有输出文件。
- 原始附件未写入或修改；输入副本位于单独的 `vsp_input/`。
