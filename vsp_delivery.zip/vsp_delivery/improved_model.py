#!/usr/bin/env python3
"""Rebuild physical-trip emissions model from original raw attachments."""
from pathlib import Path
import pandas as pd, numpy as np
ROOT=Path(__file__).resolve().parent
IN=ROOT.parent/"vsp_input"; OUT=ROOT
DATA=IN/"命题2数据附件1-2023年的订单数据和运单数据(2).xlsx"
VEH=IN/"命题2数据附件2-运输车辆的核心信息(2).xlsx"
MAP=IN/"碳排放核算口径统一版_物理行程模型(1).xlsx"
def main():
    w=pd.read_excel(DATA,sheet_name="运单数据")
    m=pd.read_excel(MAP,sheet_name="车型因子映射")
    factor=m.set_index("车型名称（附件2）").to_dict("index")
    counts_mode=w.groupby(["vehicle_number（车牌号）","vehicle_type_name（车型种类名称）"],dropna=False).size().reset_index(name="n")
    mode=counts_mode.sort_values(["vehicle_number（车牌号）","n","vehicle_type_name（车型种类名称）"],ascending=[True,False,True]).drop_duplicates("vehicle_number（车牌号）").set_index("vehicle_number（车牌号）")["vehicle_type_name（车型种类名称）"]
    key=["vehicle_number（车牌号）","实际行驶里程（km）","departure_time封车时间","arrival_time（解封车时间）","departure_site_name（封车网点名称）","arrival_site_name（解封车网点名称）"]
    counts=w.groupby(key,dropna=False).size().reset_index(name="承载运单关联记录数")
    d=w.drop_duplicates(key).copy().merge(counts,on=key,how="left")
    d["车型名称（车牌众数）"]=d["vehicle_number（车牌号）"].map(mode)
    d["燃油类型"]=d["车型名称（车牌众数）"].map(lambda x:factor.get(x,{}).get("燃油类型（附件2）","未映射"))
    d["代表因子组"]=d["车型名称（车牌众数）"].map(lambda x:factor.get(x,{}).get("代表因子组","未映射"))
    d["EF_g_km"]=d["车型名称（车牌众数）"].map(lambda x:factor.get(x,{}).get("EF采用值_g_km",np.nan))
    d["排放_kg"]=d["实际行驶里程（km）"]*d["EF_g_km"]/1000
    d["时长_h"]=(d["arrival_time（解封车时间）"]-d["departure_time封车时间"]).dt.total_seconds()/3600
    d["速度_km_h"]=d["实际行驶里程（km）"]/d["时长_h"]
    d["速度质量标记"]=np.select([d["时长_h"]<=0,d["速度_km_h"]>100,d["速度_km_h"].isna()],["时长非正","速度>100 km/h，待核验","缺失"],default="未触发速度阈值")
    d["里程段"]=pd.cut(d["实际行驶里程（km）"],[-np.inf,10,50,200,500,np.inf],labels=["A 短途 <10km","B 10–50km","C 50–200km","D 200–500km","E >500km"],right=False)
    d["月份"]=d["departure_time封车时间"].dt.to_period("M").astype(str)
    d["排放_t"]=d["排放_kg"]/1000
    d.insert(0,"行程ID",range(1,len(d)+1))
    summary=d.groupby("代表因子组",dropna=False).agg(物理行程数=("行程ID","count"),承载运单关联记录数=("承载运单关联记录数","sum"),总里程_km=("实际行驶里程（km）","sum"),总排放_kg=("排放_kg","sum")).reset_index()
    summary["排放占比"]=summary["总排放_kg"]/d["排放_kg"].sum()
    dist=d.groupby("里程段",observed=False).agg(物理行程数=("行程ID","count"),关联记录数=("承载运单关联记录数","sum"),总里程_km=("实际行驶里程（km）","sum"),总排放_kg=("排放_kg","sum")).reset_index()
    month=d.groupby("月份").agg(物理行程数=("行程ID","count"),关联记录数=("承载运单关联记录数","sum"),总里程_km=("实际行驶里程（km）","sum"),总排放_kg=("排放_kg","sum")).reset_index()
    q=pd.DataFrame([
      ["原始运单行数",len(w),"原始附件"],["原始完全重复行数",int(w.duplicated().sum()),"审计标记，不改原始文件"],
      ["物理行程数",len(d),"主口径"],["总里程_km",d["实际行驶里程（km）"].sum(),"主口径"],
      ["总排放_tCO2",d["排放_kg"].sum()/1000,"代表因子估算，非实测"],
      ["速度>100km/h行程数",int((d["速度_km_h"]>100).sum()),"只作质量标记"],
      ["缺失因子行程数",int(d["EF_g_km"].isna().sum()),"需为0"],
      ["实测油耗/CO2",0,"未提供，无法独立验证精度"],
    ],columns=["审计项","结果","说明"])
    OUT.mkdir(exist_ok=True)
    with pd.ExcelWriter(OUT/"improved_model.xlsx",engine="openpyxl") as x:
      d.to_excel(x,index=False,sheet_name="物理行程明细")
      m.to_excel(x,index=False,sheet_name="车型因子映射")
      summary.to_excel(x,index=False,sheet_name="车型组汇总")
      dist.to_excel(x,index=False,sheet_name="里程段汇总")
      month.to_excel(x,index=False,sheet_name="月份汇总")
      q.to_excel(x,index=False,sheet_name="数据质量审计")
      if (OUT/"parameter_source.xlsx").exists():
        pd.read_excel(OUT/"parameter_source.xlsx",sheet_name="参数来源").to_excel(x,index=False,sheet_name="参数来源")
      pd.DataFrame([
        ["主口径","物理行程去重","车牌+里程+封车时间+解封车时间+起终网点；不含运单号","车辆端总量，同车程只计一次"],
        ["辅口径","运单映射","运单号+物理行程字段","适用于运单归因，不等于物理行程总量"],
        ["公式","排放kg=里程km×EF g/km÷1000","代表因子来自方案4.4的映射表","非实测因子"],
        ["速度","里程÷封车到解封时长","仅用于异常标记","不代入排放主公式"],
        ["精度声明","未独立验证","无真实油耗/实测CO2","不宣称精度提升"],
      ],columns=["主题","规则","细节","限制"]).to_excel(x,index=False,sheet_name="模型说明")
    print(f"physical_trips={len(d)} km={d['实际行驶里程（km）'].sum():.2f} emissions_t={d['排放_kg'].sum()/1000:.6f} missing_EF={d['EF_g_km'].isna().sum()}")
if __name__=="__main__": main()
