#!/usr/bin/env python3
"""Rebuild the legacy waybill-linked calculation from untouched raw inputs.
This is a transparent re-calculation, not a claim that unavailable historic workbook is bitwise reproducible.
"""
from pathlib import Path
import pandas as pd, numpy as np
ROOT=Path(__file__).resolve().parent
IN=ROOT.parent/"vsp_input"; OUT=ROOT
DATA=IN/"命题2数据附件1-2023年的订单数据和运单数据(2).xlsx"
VEH=IN/"命题2数据附件2-运输车辆的核心信息(2).xlsx"
MAP=IN/"碳排放核算口径统一版_物理行程模型(1).xlsx"
REPORT_E0=4502.04241
def main():
    w=pd.read_excel(DATA,sheet_name="运单数据")
    v=pd.read_excel(VEH,sheet_name="Sheet2")
    m=pd.read_excel(MAP,sheet_name="车型因子映射")
    factor=dict(zip(m["车型名称（附件2）"].astype(str),m["EF采用值_g_km"]))
    counts_mode=w.groupby(["vehicle_number（车牌号）","vehicle_type_name（车型种类名称）"],dropna=False).size().reset_index(name="n")
    mode=counts_mode.sort_values(["vehicle_number（车牌号）","n","vehicle_type_name（车型种类名称）"],ascending=[True,False,True]).drop_duplicates("vehicle_number（车牌号）").set_index("vehicle_number（车牌号）")["vehicle_type_name（车型种类名称）"]
    cols=["vehicle_number（车牌号）","实际行驶里程（km）","departure_time封车时间","arrival_time（解封车时间）","departure_site_name（封车网点名称）","arrival_site_name（解封车网点名称）"]
    key=["waybill_number（运单号）"]+cols
    d=w.drop_duplicates(key).copy()
    d["车型映射"]=d["vehicle_number（车牌号）"].map(mode)
    d["EF_g_km"]=d["车型映射"].map(lambda x:factor.get(str(x),np.nan))
    d["排放_kg"]=d["实际行驶里程（km）"]*d["EF_g_km"]/1000
    summary=pd.DataFrame([
      ["方案4.4文档声明基准E0(t)",REPORT_E0,"文档报告值，非本次重算"],
      ["原始运单行数",len(w),"原始附件"],
      ["运单映射去重行数",len(d),"按运单号+车牌+里程+时间+网点去重"],
      ["运单映射去重里程(km)",d["实际行驶里程（km）"].sum(),"重算"],
      ["运单映射排放(t)",d["排放_kg"].sum()/1000,"原始附件+代表因子映射重算"],
      ["缺失EF记录数",int(d["EF_g_km"].isna().sum()),"应为0，否则需补映射"],
    ],columns=["项目","结果","说明"])
    OUT.mkdir(exist_ok=True)
    with pd.ExcelWriter(OUT/"original_reproduction.xlsx",engine="openpyxl") as x:
      summary.to_excel(x,index=False,sheet_name="复现结论")
      d[["waybill_number（运单号）","vehicle_number（车牌号）","车型映射","实际行驶里程（km）","EF_g_km","排放_kg"]].to_excel(x,index=False,sheet_name="旧口径关联明细")
    print(f"legacy_linked_trips={len(d)} km={d['实际行驶里程（km）'].sum():.2f} emissions_t={d['排放_kg'].sum()/1000:.6f}")
if __name__=="__main__": main()
