#!/usr/bin/env python3
"""End-to-end repeatability and deliverable integrity checks."""
from pathlib import Path
import sys, json, time, runpy, contextlib, io
import pandas as pd
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parent; WORK=ROOT.parent; OUT=ROOT
LOG=OUT/"logs"; LOG.mkdir(exist_ok=True)
REQUIRED=["data_audit.xlsx","data_quality.md","original_reproduction.py","original_reproduction.xlsx","parameter_source.xlsx","improved_model.py","improved_model.xlsx","model_change_log.md","comparison.xlsx","sensitivity.xlsx","comparison_report.md","run_all.py","requirements.txt","README.md"]
def main():
    runs=[]
    # execute each model twice in this process to avoid interpreter startup overhead
    for n in (1,2):
        for script in ("original_reproduction.py","improved_model.py"):
            buf=io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    runpy.run_path(str(OUT/script),run_name="__main__")
                runs.append({"pass":n,"script":script,"returncode":0,"stdout":buf.getvalue(),"stderr":""})
            except Exception as e:
                runs.append({"pass":n,"script":script,"returncode":1,"stdout":buf.getvalue(),"stderr":repr(e)})
                raise
    model=pd.read_excel(OUT/"improved_model.xlsx",sheet_name="物理行程明细")
    orig=pd.read_excel(OUT/"original_reproduction.xlsx",sheet_name="复现结论")
    ntrips=len(model); km=float(model["实际行驶里程（km）"].sum()); tonnes=float(model["排放_kg"].sum()/1000)
    lr=orig[orig["项目"]=="运单映射排放(t)"]; legacy_t=float(lr["结果"].iloc[0]) if not lr.empty else float("nan")
    missing=[x for x in REQUIRED if not (OUT/x).is_file()]
    if missing: raise RuntimeError(f"missing required files: {missing}")
    excels=[]
    for f in sorted(OUT.glob("*.xlsx")):
        wb=load_workbook(f,read_only=True,data_only=False); sheets=wb.sheetnames; wb.close()
        excels.append({"file":f.name,"sheets":sheets,"size":f.stat().st_size})
    if any(not e["sheets"] for e in excels): raise RuntimeError("workbook has no worksheets")
    obj={"timestamp_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"runs":runs,
      "numeric_results":{"physical_trips":ntrips,"physical_km":round(km,2),"physical_emissions_t":round(tonnes,6),"legacy_linked_emissions_t":round(legacy_t,6)},
      "missing_required_files":missing,"excel_checks":excels,"status":"PASS"}
    (LOG/"run_all.log").write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(obj["numeric_results"],ensure_ascii=False))
if __name__=="__main__": main()
