# T5 端到端测试记录

## 测试环境
- Python：3.13.5
- pandas：2.2.3
- openpyxl：3.1.5
- 输入目录：`/mnt/data/vsp_input`
- 输出目录：`/mnt/data/vsp_delivery`

## 第1轮：端到端运行
执行入口：`python vsp_delivery/run_all.py`（本轮在当前 Python 运行环境中执行 `run_all.py`，脚本内部调用两个模型脚本）。
- `original_reproduction.py`：退出码 0；33,214 条运单映射去重记录，里程 4,690,435.81 km，排放 4,649.103921 t。
- `improved_model.py`：退出码 0；12,167 趟物理行程，里程 2,174,173.86 km，排放 2,338.931589 t；缺失排放因子行程数 0。
- 状态：通过。

## 第2轮：连续两次运行一致性
`run_all.py` 在同一执行中连续运行两个模型脚本两次。两次打印结果完全一致：
- 旧口径：`legacy_linked_trips=33214 km=4690435.81 emissions_t=4649.103921`
- 新口径：`physical_trips=12167 km=2174173.86 emissions_t=2338.931589 missing_EF=0`
- 状态：通过；结果一致不代表精度提高。

## 第3轮：交付文件与Excel可读性
- 必需交付文件逐项存在：缺失项 0。
- 检查工作簿：6 个 `.xlsx` 文件均由 `openpyxl.load_workbook` 成功打开并读取工作表。
- `logs/run_all.log` 记录逐项检查、工作表名称、文件大小、两轮模型执行命令/输出。
- 状态：通过。

## 失败与修复记录
- 初版脚本相对路径误指向 `vsp_delivery/vsp_input/`，实际输入目录是工作区根目录下的 `vsp_input/`。已修正为 `ROOT.parent / "vsp_input"`，并重新运行成功。
- 初版车型众数计算重复调用 `Series.mode()`，执行较慢。已改为车型标签计数后排序取众数，并重跑成功。
- 当前没有真实油耗或实测CO₂数据，因此独立精度验证未开展；这属于证据缺口，不是程序测试失败。
